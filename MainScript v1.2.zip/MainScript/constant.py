import os

File_Path = fr"{os.path.dirname(os.path.realpath(__file__))}"
